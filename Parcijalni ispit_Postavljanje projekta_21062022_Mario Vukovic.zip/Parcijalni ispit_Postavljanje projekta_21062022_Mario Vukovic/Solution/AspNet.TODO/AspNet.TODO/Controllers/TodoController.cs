﻿using AspNet.TODO.Models;
using AspNet.TODO.Repository.Interface;
using Microsoft.AspNetCore.Mvc;

namespace AspNet.TODO.Controllers
{
    public class TodoController : Controller
    {
        private readonly ITodoRepository todoRepository;

        public TodoController(ITodoRepository todoRepository)
        {
            this.todoRepository = todoRepository;
        }

        public IActionResult Index()
        {
            return View(todoRepository.Get());
        }
    }
}
