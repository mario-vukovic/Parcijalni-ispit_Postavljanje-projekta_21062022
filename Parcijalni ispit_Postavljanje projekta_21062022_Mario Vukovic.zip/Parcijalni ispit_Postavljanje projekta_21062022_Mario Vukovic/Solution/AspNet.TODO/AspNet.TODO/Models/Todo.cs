﻿using AspNet.TODO.Models.Base;

namespace AspNet.TODO.Models
{
    public class Todo:EntityBase
    {
        public int LevelOfImportance { get; set; }
        public string Name { get; set; }
        public bool Finished { get; set; }
        public DateTime FinishTime { get; set; }
    }
}
