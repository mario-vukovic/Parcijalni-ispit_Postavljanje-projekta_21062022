﻿using AspNet.TODO.Models;
using AspNet.TODO.Repository.Interface;

namespace AspNet.TODO.Repository
{
    public class TodoRepository : IRepository<Todo>, ITodoRepository
    {
        public List<Todo> Get()
        {
            return new List<Todo>
            {
                new Todo
                {
                    Id = 1,
                    Created = DateTime.Now.AddHours(-1),
                    LevelOfImportance = 2,
                    Name = "Clean bathroom",
                    Finished = false
                },
                new Todo
                {
                    Id = 2,
                    Created = DateTime.Now.AddHours(-5),
                    LevelOfImportance = 5,
                    Name = "Call mom",
                    Finished = false
                },
                new Todo
                {
                    Id = 3,
                    Created = DateTime.Now.AddHours(-2),
                    LevelOfImportance = 4,
                    Name = "Drink water",
                    Finished = false
                },
                new Todo
                {
                    Id = 4,
                    Created = DateTime.Now.AddHours(-15),
                    LevelOfImportance = 5,
                    Name = "Finish exam",
                    Finished = true,
                    FinishTime = DateTime.Now
                },
                new Todo
                {
                    Id = 5,
                    Created = DateTime.Now.AddHours(-3),
                    LevelOfImportance = 1,
                    Name = "Sleep",
                    Finished = false
                },

            };
        }

        public Todo GetById(int id)
        {
            return Get().FirstOrDefault(x => x.Id == id);
        }

        public void Insert(Todo entity)
        {
            throw new NotImplementedException();
        }

        public void Update(Todo entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }
    }
}
