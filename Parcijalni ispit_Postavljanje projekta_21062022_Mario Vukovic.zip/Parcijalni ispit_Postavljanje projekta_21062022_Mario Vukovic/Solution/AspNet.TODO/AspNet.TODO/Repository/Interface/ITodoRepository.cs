﻿using AspNet.TODO.Models;

namespace AspNet.TODO.Repository.Interface;

public interface ITodoRepository
{
    List<Todo> Get();
    Todo GetById(int id);
    void Insert(Todo entity);
    void Update(Todo entity);
    void Delete(int id);
}